import boto3
from botocore.client import Config
from botocore.exceptions import ClientError
import os
from typing import List, Optional

def create_s3_client(access_key: str, secret_key: str, endpoint: str = "https://s3.nevaobjects.id"):
    """
    Client dengan fix checksum untuk S3-compatible seperti Neva Objects
    """
    return boto3.client(
        's3',
        endpoint_url=endpoint,
        aws_access_key_id=access_key,
        aws_secret_access_key=secret_key,
        config=Config(
            signature_version='s3v4',
            s3={'addressing_style': 'path'},
            request_checksum_calculation="when_required", 
            response_checksum_validation="when_required"
        )
    )


def upload(bucket: str, access_key: str, secret_key: str, local_path: str, object_key: Optional[str] = None) -> bool:
    """
    Upload file (sudah fix checksum mismatch)
    """
    if not os.path.isfile(local_path):
        print(f"File tidak ditemukan: {local_path}")
        return False

    if object_key is None:
        object_key = os.path.basename(local_path)

    s3 = create_s3_client(access_key, secret_key)

    try:
        s3.upload_file(
            Filename=local_path,
            Bucket=bucket,
            Key=object_key
        )
        print(f"Berhasil upload: {local_path} → s3://{bucket}/{object_key}")
        return True
    except ClientError as e:
        err_code = e.response['Error']['Code']
        err_msg = e.response['Error'].get('Message', '(no message)')
        print(f"Upload gagal: {err_code} - {err_msg}")
        return False
    except Exception as e:
        print(f"Error tidak terduga: {str(e)}")
        return False


def list_files(bucket: str, access_key: str, secret_key: str) -> List[str]:
    s3 = create_s3_client(access_key, secret_key)
    
    try:
        response = s3.list_objects_v2(Bucket=bucket)
        if 'Contents' not in response:
            return []
        return [obj['Key'] for obj in response['Contents']]
    except ClientError as e:
        print(f"Gagal list: {e.response['Error']['Code']} - {e.response['Error'].get('Message', '')}")
        return []
    except Exception as e:
        print(f"Error list: {str(e)}")
        return []


def get_download_url(bucket: str, access_key: str, secret_key: str, object_key: str, expires_in: int = 86400) -> Optional[str]:
    s3 = create_s3_client(access_key, secret_key)
    
    try:
        url = s3.generate_presigned_url(
            'get_object',
            Params={'Bucket': bucket, 'Key': object_key},
            ExpiresIn=expires_in
        )
        return url
    except ClientError as e:
        print(f"Gagal generate URL: {e.response['Error']['Code']} - {e.response['Error'].get('Message', '')}")
        return None
    except Exception as e:
        print(f"Error generate URL: {str(e)}")
        return None